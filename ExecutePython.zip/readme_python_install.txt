1. Download python from http://www.python.org/download/
   (Direct Link: http://www.python.org/ftp/python/3.3.2/python-3.3.2.msi)

2. Install it (Just do default install)

3. Know your python (py.exe) installation directory

Your PhpCompiler path should be this

c:\Python33\Python.exe


